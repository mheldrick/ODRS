<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form class="" action="send.php" method="post">
        Email <input type="text" name="email" value=""> <br>
        Subject <input type="text" name="subject" value=""> <br>
        Message <input type="text" name="message" value=""> <br>
        <button type="submit" name="send">Send</button>
    </form>
</body>
</html>